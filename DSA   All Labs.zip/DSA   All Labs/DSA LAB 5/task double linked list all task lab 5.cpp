#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* prev;
    Node* next;
};

Node* head = NULL;

// Function to create doubly linked list from user input
void createList(int n) {
    Node* temp;
    Node* newNode;
    int value;

    for (int i = 0; i < n; i++) {
        cout << "Enter mark " << i + 1 << ": ";
        cin >> value;

        newNode = new Node;
        newNode->data = value;
        newNode->prev = NULL;
        newNode->next = NULL;

        if (head == NULL) {
            head = newNode;
        } else {
            temp = head;
            while (temp->next != NULL)
                temp = temp->next;
            temp->next = newNode;
            newNode->prev = temp;
        }
    }
}

// Add at beginning
void addAtBeginning(int value) {
    Node* newNode = new Node;
    newNode->data = value;
    newNode->prev = NULL;
    newNode->next = head;

    if (head != NULL)
        head->prev = newNode;
    head = newNode;
}

// Add after node with value 45
void addAfterValue(int value, int newValue) {
    Node* temp = head;
    while (temp != NULL && temp->data != value) {
        temp = temp->next;
    }

    if (temp == NULL) {
        cout << "Value " << value << " not found!\n";
        return;
    }

    Node* newNode = new Node;
    newNode->data = newValue;
    newNode->next = temp->next;
    newNode->prev = temp;

    if (temp->next != NULL)
        temp->next->prev = newNode;

    temp->next = newNode;
}

// Delete at beginning
void deleteAtBeginning() {
    if (head == NULL) {
        cout << "List is empty!\n";
        return;
    }

    Node* temp = head;
    head = head->next;

    if (head != NULL)
        head->prev = NULL;

    delete temp;
}

// Delete node after value 45
void deleteAfterValue(int value) {
    Node* temp = head;
    while (temp != NULL && temp->data != value) {
        temp = temp->next;
    }

    if (temp == NULL || temp->next == NULL) {
        cout << "No node exists after value " << value << "\n";
        return;
    }

    Node* delNode = temp->next;
    temp->next = delNode->next;

    if (delNode->next != NULL)
        delNode->next->prev = temp;

    delete delNode;
}

// Display list
void display() {
    Node* temp = head;
    cout << "List: ";
    while (temp != NULL) {
        cout << temp->data << " <-> ";
        temp = temp->next;
    }
    cout << "NULL\n";
}

int main() {
    int n;
    cout << "Enter number of nodes: ";
    cin >> n;
    createList(n);
    display();

    cout << "\nAdding 100 at beginning...\n";
    addAtBeginning(100);
    display();

    cout << "\nAdding 200 after 45...\n";
    addAfterValue(45, 200);
    display();

    cout << "\nDeleting at beginning...\n";
    deleteAtBeginning();
    display();

    cout << "\nDeleting node after 45...\n";
    deleteAfterValue(45);
    display();

    return 0;
}
