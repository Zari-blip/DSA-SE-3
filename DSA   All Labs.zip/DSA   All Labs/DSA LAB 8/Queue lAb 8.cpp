#include<iostream>
using namespace std;
int queue[5],n=5,front=-1,rare=-1,val;
//  n=size    
void enqueue(){
	if(rare==n-1){
		cout<<" Queue overflow";
	}
	 else {
	 	 if(front==-1)front++;
	 	  rare++;
	 	  cout<<"  Enter value: "<<endl;
	 	  cin>>val;
	 	  queue[rare]=val;
	 }
	 
}
 
  void  dequeue(){
  	if (rare==-1&& front==-1){
  		cout<<" Queue underflow ";
  		
	  }
	   else {
	   	if(front ==rare){
	   		front=-1;
	   		rare=-1;
		   }
		   else {
		   cout<< " Element is deleted "<<queue[front]<<endl;
	   	 front ++;
	   	    }
	   }
  	
  }
 int main (){
 	
 	 for(int i=0; i<n; i++){
 	 	enqueue();
	  } 
	
	  for(int i=0; i<2; i++){
 	 	dequeue();
	  } 
 return 0;	  
 }

