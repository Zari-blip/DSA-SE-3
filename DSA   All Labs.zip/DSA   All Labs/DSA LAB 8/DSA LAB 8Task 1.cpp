#include<iostream>
using namespace std;

int main() {

    struct Applicant {
        int id;
        float height;
        float weight;
        float eyesight;
        string status;
        Applicant* next;
        Applicant* prev;
    };

    Applicant* front = NULL;
    Applicant* rear = NULL;

    
    cout << "\nEnter details for seven Applicants:\n";
    for(int i = 1; i <= 7; i++) {

        Applicant* newAp = new Applicant;

        newAp->id = 100 + i;
        cout << "\nEnter Height (cm) for Applicant " << newAp->id << ": ";
        cin >> newAp->height;
        cout << "Enter Weight (kg): ";
        cin >> newAp->weight;
        cout << "Enter Eyesight (e.g., 6.6, 6.18): ";
        cin >> newAp->eyesight;

        newAp->status = "Waiting"; // initially waiting
        newAp->next = NULL;
        newAp->prev = rear;

        if(front == NULL) {
            front = rear = newAp;
        } else {
            rear->next = newAp;
            rear = newAp;
        }
    }

    
    cout << "\n--- Initial Queue (7 Applicants) ---\n";
    Applicant* p = front;
    while(p != NULL) {
        cout << "\nID: " << p->id 
             << "\nHeight: " << p->height 
             << "\nWeight: " << p->weight
             << "\nEyesight: " << p->eyesight
             << "\nStatus: " << p->status << endl;
        p = p->next;
    }

    cout << "\nTest Done: Applicant " << front->id << " Removed!\n";
    front->status = "Test Completed";
    Applicant* temp = front;
    front = front->next;
    front->prev = NULL;
    delete temp;

    // ? REMOVE 2nd person (urgent exit)
    cout << "\nUrgent Exit: Applicant " << front->next->id << " Removed!\n";
    Applicant* temp2 = front->next;
    front->next = temp2->next;

    if(temp2->next != NULL) {
        temp2->next->prev = front;
    } else {
        rear = front;
    }
    delete temp2;

   // Remaining Queue
    cout << "\n--- Remaining Applicants ---\n";
    p = front;
    while(p != NULL) {
        cout << "\nID: " << p->id 
             << "\nHeight: " << p->height 
             << "\nWeight: " << p->weight
             << "\nEyesight: " << p->eyesight
             << "\nStatus: " << p->status << endl;
        p = p->next;
    }

    return 0;
}

