#include<iostream>
using namespace std;
struct node{
	int data;
	node* next;
	node(int value)
	{
		data=value;
		next=NULL;
	}};
	void insertatTail(int value,node* &head){
		cout<<"Enter a value that you want to insert at tail:";
		cin>>value;
		node* n=new node(value);
		node* temp=head;
		if(head==NULL){
			head=n;
		}
		while(temp->next!=NULL){
			temp=temp->next;
		}
		temp->next=n;
	}
	void insertathead(node*&head, int value){
		cout<<"  Enter a value that you want to insert at head    ";
		cin>>value;
		node* n=new node(value);
	
		n->next=head;
		head=n;	
	}
void insertatpos(int pos,int value,node* &head){
	cout<<" Enter position and value that you want to insert: ";
	cin>>pos>>value;
	node* n=new node(value);
	node* temp=head;
	if(pos==1){
		n->next=head;
		head=n;
		return;
	}
	else{
		
	 temp=head;
	for(int i=1;i<pos-1&&temp->next!=NULL;i++){
		temp=temp->next;
		
	}
	if(temp==NULL){
		cout<<"POsition is out of range";
	}
	n->next=temp->next;
	temp->next=n;
}

}	
void del(int pos, node* &head, int value){
	cout<<" Enter position that you want to delete: ";
	cin>>pos;

	if(pos==1){
		node* temp=head;
		head=head->next;
		delete temp;
		return;
	}
	node* temp=head;
	for(int i=1;i<pos-1&&temp->next!=NULL;i++){
	
		temp=temp->next;
	}
	if(temp==NULL||temp->next==NULL)
	{
		cout<<"Position is out of range";
	}
	node* delnode=temp->next;
	temp->next=delnode->next;
	delete delnode;
	
}	
void display(node* &head){
	node* temp=head;
	while(temp!=NULL){
		cout<<temp->data<<" ";
		temp=temp->next;
	}
	cout<<"NULL";
	
	
	
	
	
}	
	
int main(){
	int data;
	int pos,value,n;
	node* head=NULL;
	cout<<"How many numbers you want to add:";
	cin>>n;
	cout<<"Enter "<<n<<" values";
	for(int i=0;i<n;i++){
		cin>>value;
		node* nn=new node(value);
		if(head==NULL){
			head=nn;
		}
		else{
			node* temp=head;
			while(temp->next!=NULL){
				temp=temp->next;
			}
			temp->next=nn;
		}
	}
		display(head);
	insertatTail(value,head);
	display(head);
	insertathead(head,value);
		display(head);
	insertatpos(pos,value,head);
		display(head);
	del(pos,head,value);
		display(head);
	
	
	
return 0;	
	
}