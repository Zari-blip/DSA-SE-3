#include <iostream>
using namespace std;

class Inventory {
public:
    int serialNum;
    int manufactYear;
    int lotNum;

    void setData(int s, int y, int l) {
        serialNum = s;
        manufactYear = y;
        lotNum = l;
    }

    void showData() {
        cout << "Serial No: " << serialNum << endl;
        cout << "Manufact Year: " << manufactYear << endl;
        cout << "Lot No: " << lotNum << endl;
        cout << "--------------------" << endl;
    }
};

struct Node {
    Inventory data;
    Node* next;
};

class Stack {
public:
    Node* top;

    Stack() {
        top = nullptr; // initialize top to null
    }

    void push(Inventory part) {
        Node* newNode = new Node;
        newNode->data = part;
        newNode->next = top; // link new node to old top
        top = newNode;       // move top to new node
        cout << "Part added successfully!" << endl;
    }

    void pop() {
        if (top == nullptr) {
            cout << "Inventory is empty!" << endl;
        } else {
            cout << "\nPart removed from inventory:\n";
            top->data.showData(); // show top item before removing

            Node* temp = top;     // hold current top
            top = top->next;      // move top to next node
            delete temp;          // free old top memory

            cout << "Part removed successfully!\n";
        }
    }

    void showAll() {
        if (top == nullptr) {
            cout << "No parts left in inventory!\n";
        } else {
            cout << "\nParts left in inventory:\n";
            Node* temp = top;
            while (temp != nullptr) {
                temp->data.showData();
                temp = temp->next;
            }
        }
    }
};

int main() {
    Stack s;
    int ch;

    do {
        cout << "\n1. Add Part";
        cout << "\n2. Remove Part";
        cout << "\n3. Exit";
        cout << "\nEnter choice: ";
        cin >> ch;

        if (ch == 1) {
            Inventory part;
            int sn, yr, ln;

            cout << "Enter Serial Number: ";
            cin >> sn;
            cout << "Enter Manufacture Year: ";
            cin >> yr;
            cout << "Enter Lot Number: ";
            cin >> ln;

            part.setData(sn, yr, ln);
            s.push(part);
        }
        else if (ch == 2) {
            s.pop();
        }
        else if (ch == 3) {
            cout << "\nExiting program...\n";
        }
        else {
            cout << "Invalid choice!\n";
        }

    } while (ch != 3);

    s.showAll();

    return 0;
}
