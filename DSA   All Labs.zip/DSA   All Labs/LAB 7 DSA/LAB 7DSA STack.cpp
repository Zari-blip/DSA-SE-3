#include<iostream>
using namespace std;
struct book{ 
string title;
double price;
int page;
int edition;
};
book stackarr[10];
int top=-1;

void push(book b){
if(top==9){
	cout<<"  Stack is full  "<<endl;
	
} else{
	top++;
	stackarr[top]=b;
	cout<<"  Book Pushed "<<b.title<<endl;
	
}
}
void pop(){
	if(top==-1){
		cout<<"  Stack is full  "<<endl;	
	} else{
		cout<<" Book poped: "<< stackarr[top].title<<endl;
		top--;
	}
}

void peek(){
	if(top==-1){
		cout<<"  Stack is full  "<<endl;	
	} else{
		 cout << "Top Book:" << endl;
        cout << "Title: " <<stackarr[top].title << endl;
        cout << "Price: " << stackarr[top].price << endl;
        cout << "Edition: " << stackarr[top].edition << endl;
        cout << "Pages: " << stackarr[top].page << endl;
        cout << "-------------------" << endl;
}}

void display(){
		if(top==-1){
		cout<<"  Stack is full  "<<endl;	
	} else{
		 cout << "Books in Stack:" << endl;
        for (int i = top; i >= 0; i--) {
            cout << "Title: " << stackarr[i].title << endl;
            cout << "Price: " << stackarr[i].price << endl;
            cout << "Edition: " << stackarr[i].edition << endl;
            cout << "Pages: " << stackarr[i].page << endl;
            cout << "-------------------" << endl;
        }
}
}

int main(){
	
	book b1={"PF", 500 , 2, 11};
	book b2={"DSA",300, 24, 800};
	book b3={"DLD",4500,5,900};
	book b4={"MVC",3400,10,360};
	book b5={"QAD",1000,4,560};
	push(b1);
    push(b2);
    push(b3);
    push(b4);
    push(b5);
    
    peek();
    
    pop();
    pop();
    
    display();
    return 0;
}